import os
from employee_database_class_yaml import EmployeeDatabase

FILE = "employee_records_DB.yaml"


def fresh_db():
    """Delete any old YAML file and return a new EmployeeDatabase."""
    if os.path.exists(FILE):
        os.remove(FILE)
    return EmployeeDatabase()


def report(name, expected, actual):
    status = "PASS" if expected == actual else "FAIL"
    print(f"{status}: {name}")
    print(f"  Expected: {expected}")
    print(f"  Actual:   {actual}")
    print()


# Test 1: insert one employee and fetch them
db = fresh_db()
db.insert_employee("John", "Doe", "1980-01-15", "2020-06-10", "Software Engineer")
report(
    "Insert and fetch one employee",
    "ID: 1, Name: John Doe, Birthdate: 1980-01-15, Hire Date: 2020-06-10, Job Title: Software Engineer",
    db.get_employee("John", "Doe"),
)

# Test 2: fetch an employee who does not exist
db = fresh_db()
db.insert_employee("John", "Doe", "1980-01-15", "2020-06-10", "Software Engineer")
report("Fetch employee who does not exist", None, db.get_employee("Jane", "Smith"))

# Test 3: IDs auto increment
db = fresh_db()
db.insert_employee("John", "Doe", "1980-01-15", "2020-06-10", "Software Engineer")
db.insert_employee("Jane", "Smith", "1990-03-22", "2021-09-01", "Data Analyst")
report(
    "Second employee gets ID 2",
    "ID: 2, Name: Jane Smith, Birthdate: 1990-03-22, Hire Date: 2021-09-01, Job Title: Data Analyst",
    db.get_employee("Jane", "Smith"),
)

# Test 4: get_all_employees returns everyone
expected_all = [
    {"id": 1, "first_name": "John", "last_name": "Doe", "birthdate": "1980-01-15",
     "hire_date": "2020-06-10", "job_title": "Software Engineer"},
    {"id": 2, "first_name": "Jane", "last_name": "Smith", "birthdate": "1990-03-22",
     "hire_date": "2021-09-01", "job_title": "Data Analyst"},
]
report("get_all_employees returns both records", expected_all, db.get_all_employees())

# Test 5: a new YAML file is created when none exists
if os.path.exists(FILE):
    os.remove(FILE)
db = EmployeeDatabase()
report("YAML file is created if missing", True, os.path.exists(FILE))
report("New database starts empty", [], db.get_all_employees())