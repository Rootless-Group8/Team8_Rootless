"""Test cases for the XML Adapter. Run: python test_xml_adapter.py -v"""
import os
import tempfile
import unittest

from employee_database_class_xml import EmployeeDatabase as XmlDB
from employee_database_class_json import EmployeeDatabase as JsonDB
from employee_database_class_sql import EmployeeDatabase as SqlDB

JOHN = ("John", "Doe", "1980-01-15", "2020-06-10", "Software Engineer")
JANE = ("Jane", "Smith", "1990-03-22", "2021-09-01", "Data Analyst")
EXPECTED_JOHN = ("ID: 1, Name: John Doe, Birthdate: 1980-01-15, "
                 "Hire Date: 2020-06-10, Job Title: Software Engineer")


class XmlAdapterTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.dir.name, "emp.xml")
        self.db = XmlDB(self.path)

    def tearDown(self):
        self.dir.cleanup()

    # TC1
    def test_01_file_created_on_init(self):
        self.assertTrue(os.path.exists(self.path))

    # TC2
    def test_02_existing_file_not_overwritten(self):
        self.db.insert_employee(*JOHN)
        XmlDB(self.path)  # re-open
        self.assertEqual(len(XmlDB(self.path).get_all_employees()), 1)

    # TC3
    def test_03_insert_then_get_exact_format(self):
        self.db.insert_employee(*JOHN)
        self.assertEqual(self.db.get_employee("John", "Doe"), EXPECTED_JOHN)

    # TC4
    def test_04_get_missing_returns_none(self):
        self.assertIsNone(self.db.get_employee("No", "Body"))
        self.db.insert_employee(*JOHN)
        self.assertIsNone(self.db.get_employee("John", "Smith"))

    # TC5
    def test_05_ids_auto_increment(self):
        self.db.insert_employee(*JOHN)
        self.db.insert_employee(*JANE)
        self.assertTrue(self.db.get_employee("Jane", "Smith").startswith("ID: 2,"))

    # TC6
    def test_06_get_all_empty(self):
        self.assertEqual(self.db.get_all_employees(), [])

    # TC7
    def test_07_get_all_returns_list_of_dicts(self):
        self.db.insert_employee(*JOHN)
        self.db.insert_employee(*JANE)
        rows = self.db.get_all_employees()
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0], {"id": 1, "first_name": "John", "last_name": "Doe",
                                   "birthdate": "1980-01-15", "hire_date": "2020-06-10",
                                   "job_title": "Software Engineer"})
        self.assertIsInstance(rows[1]["id"], int)

    # TC8
    def test_08_persists_across_instances(self):
        self.db.insert_employee(*JOHN)
        self.assertEqual(XmlDB(self.path).get_employee("John", "Doe"), EXPECTED_JOHN)

    # TC9
    def test_09_duplicate_names_returns_first(self):
        self.db.insert_employee(*JOHN)
        self.db.insert_employee("John", "Doe", "1970-01-01", "2000-01-01", "Manager")
        self.assertEqual(self.db.get_employee("John", "Doe"), EXPECTED_JOHN)
        self.assertEqual(len(self.db.get_all_employees()), 2)

    # TC10
    def test_10_special_characters_round_trip(self):
        self.db.insert_employee("A&B", "<O'Neil>", "1980-01-15", "2020-06-10", 'VP "Ops" & Sales')
        out = self.db.get_employee("A&B", "<O'Neil>")
        self.assertIn('Job Title: VP "Ops" & Sales', out)

    # TC11: parity with the two provided adapters
    def test_11_output_identical_to_json_and_sql_adapters(self):
        j = JsonDB(os.path.join(self.dir.name, "emp.json"))
        s = SqlDB(os.path.join(self.dir.name, "emp.sql"))
        for d in (self.db, j, s):
            d.insert_employee(*JOHN)
            d.insert_employee(*JANE)
        for first, last in (("John", "Doe"), ("Jane", "Smith")):
            x = self.db.get_employee(first, last)
            self.assertEqual(x, j.get_employee(first, last))
            self.assertEqual(x, s.get_employee(first, last))
        self.assertEqual(self.db.get_all_employees(), j.get_all_employees())
        s.close_connection()


if __name__ == "__main__":
    unittest.main(verbosity=2)
