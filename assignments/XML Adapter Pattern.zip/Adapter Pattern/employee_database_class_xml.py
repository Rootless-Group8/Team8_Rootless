import os
import xml.etree.ElementTree as ET


class EmployeeDatabase:
    """XML Adapter: same public interface as the JSON and SQL adapters."""

    def __init__(self, FILE_PATH="employee_records_DB.xml"):
        """Initialize by ensuring the XML file exists."""
        self.FILE_PATH = FILE_PATH
        if not os.path.exists(self.FILE_PATH):
            self._write_tree(ET.Element("employees"))  # Start with an empty root

    def _read_tree(self):
        """Read and return the root element from the XML file."""
        return ET.parse(self.FILE_PATH).getroot()

    def _write_tree(self, root):
        """Write the root element to the XML file."""
        ET.indent(root, space="    ")
        ET.ElementTree(root).write(self.FILE_PATH, encoding="utf-8", xml_declaration=True)

    @staticmethod
    def _to_dict(node):
        """Convert an <employee> element into a dict matching the JSON adapter's records."""
        return {
            "id": int(node.findtext("id")),
            "first_name": node.findtext("first_name"),
            "last_name": node.findtext("last_name"),
            "birthdate": node.findtext("birthdate"),
            "hire_date": node.findtext("hire_date"),
            "job_title": node.findtext("job_title"),
        }

    def insert_employee(self, first_name, last_name, birthdate, hire_date, job_title):
        """Insert a new employee into the XML file."""
        root = self._read_tree()
        employee_id = len(root.findall("employee")) + 1  # Auto-increment ID
        node = ET.SubElement(root, "employee")
        for tag, value in (
            ("id", employee_id),
            ("first_name", first_name),
            ("last_name", last_name),
            ("birthdate", birthdate),
            ("hire_date", hire_date),
            ("job_title", job_title),
        ):
            ET.SubElement(node, tag).text = str(value)
        self._write_tree(root)

    def get_employee(self, first_name, last_name):
        """Retrieve a specific employee by name."""
        for node in self._read_tree().findall("employee"):
            emp = self._to_dict(node)
            if emp["first_name"] == first_name and emp["last_name"] == last_name:
                return (
                    f"ID: {emp['id']}, Name: {emp['first_name']} {emp['last_name']}, "
                    f"Birthdate: {emp['birthdate']}, Hire Date: {emp['hire_date']}, "
                    f"Job Title: {emp['job_title']}"
                )
        return None  # Employee not found

    def get_all_employees(self):
        """Retrieve all employees."""
        return [self._to_dict(n) for n in self._read_tree().findall("employee")]
