"""Test cases for the CSV Adapter. Run: python3 test_csv_adapter.py -v

TC1  New DB file is created and starts empty
TC2  insert + get_employee returns the exact expected string
TC3  get_employee for a non-existent person returns None
TC4  IDs auto-increment (1, 2, 3)
TC5  get_employee matches on BOTH first and last name
TC6  get_all_employees returns list of dicts with correct keys/values
TC7  Data persists across separate EmployeeDatabase instances
TC8  Special characters (commas, quotes, &) round-trip correctly
TC9  FORM/FIT/FUNCTION: CSV output is identical to the JSON adapter's output
     for the same sequence of operations (get_employee and get_all_employees)
"""
import os, tempfile, unittest
from employee_database_class_csv import EmployeeDatabase as CsvDB
from employee_database_class_json import EmployeeDatabase as JsonDB


class TestCsvAdapter(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.dir.name, "test.csv")
        self.db = CsvDB(self.path)

    def tearDown(self):
        self.dir.cleanup()

    def test_tc1_new_file_created_empty(self):
        self.assertTrue(os.path.exists(self.path))
        self.assertEqual(self.db.get_all_employees(), [])

    def test_tc2_insert_and_get(self):
        self.db.insert_employee("John", "Doe", "1980-01-15", "2020-06-10", "Software Engineer")
        self.assertEqual(self.db.get_employee("John", "Doe"),
            "ID: 1, Name: John Doe, Birthdate: 1980-01-15, Hire Date: 2020-06-10, Job Title: Software Engineer")

    def test_tc3_not_found(self):
        self.assertIsNone(self.db.get_employee("Nobody", "Here"))

    def test_tc4_autoincrement(self):
        for n in ("A", "B", "C"):
            self.db.insert_employee(n, "X", "1990-01-01", "2020-01-01", "T")
        self.assertEqual([e["id"] for e in self.db.get_all_employees()], [1, 2, 3])

    def test_tc5_match_both_names(self):
        self.db.insert_employee("John", "Doe", "1980-01-15", "2020-06-10", "Engineer")
        self.assertIsNone(self.db.get_employee("John", "Smith"))
        self.assertIsNone(self.db.get_employee("Jane", "Doe"))

    def test_tc6_get_all(self):
        self.db.insert_employee("John", "Doe", "1980-01-15", "2020-06-10", "Engineer")
        self.assertEqual(self.db.get_all_employees(), [{
            "id": 1, "first_name": "John", "last_name": "Doe", "birthdate": "1980-01-15",
            "hire_date": "2020-06-10", "job_title": "Engineer"}])

    def test_tc7_persistence(self):
        self.db.insert_employee("John", "Doe", "1980-01-15", "2020-06-10", "Engineer")
        db2 = CsvDB(self.path)
        self.assertIsNotNone(db2.get_employee("John", "Doe"))
        db2.insert_employee("Jane", "Roe", "1985-05-05", "2021-01-01", "Analyst")
        self.assertEqual(len(CsvDB(self.path).get_all_employees()), 2)

    def test_tc8_special_characters(self):
        self.db.insert_employee("Ann, Jr.", 'O"Brien', "1980-01-15", "2020-06-10", 'R&D, "Lead"')
        self.assertEqual(self.db.get_employee("Ann, Jr.", 'O"Brien'),
            "ID: 1, Name: Ann, Jr. O\"Brien, Birthdate: 1980-01-15, Hire Date: 2020-06-10, Job Title: R&D, \"Lead\"")

    def test_tc9_identical_to_json_adapter(self):
        jpath = os.path.join(self.dir.name, "test.json")
        j = JsonDB(jpath)
        rows = [("John", "Doe", "1980-01-15", "2020-06-10", "Software Engineer"),
                ("Jane", "Roe", "1985-05-05", "2021-01-01", "Analyst"),
                ("John", "Doe", "1991-02-02", "2022-02-02", "Duplicate Name")]
        for r in rows:
            self.db.insert_employee(*r); j.insert_employee(*r)
        for name in [("John", "Doe"), ("Jane", "Roe"), ("No", "One")]:
            self.assertEqual(self.db.get_employee(*name), j.get_employee(*name))
        self.assertEqual(self.db.get_all_employees(), j.get_all_employees())


if __name__ == "__main__":
    unittest.main()
