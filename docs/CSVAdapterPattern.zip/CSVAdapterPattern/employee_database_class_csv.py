import csv
import os


class EmployeeDatabase:
    """CSV Adapter: same interface as the JSON and SQL EmployeeDatabase classes."""

    FIELDS = ["id", "first_name", "last_name", "birthdate", "hire_date", "job_title"]

    def __init__(self, FILE_PATH="employee_records_DB.csv"):
        """Initialize by ensuring the CSV file exists (with a header row)."""
        self.FILE_PATH = FILE_PATH
        if not os.path.exists(self.FILE_PATH):
            self._write_csv([])     # Header row

    def _read_csv(self):
        """Read and return all rows from the CSV file as a list of dicts."""
        with open(self.FILE_PATH, "r", newline="", encoding="utf-8") as file:
            rows = list(csv.DictReader(file))
        for row in rows:
            row["id"] = int(row["id"])  # CSV stores everything as text
        return rows

    def _write_csv(self, rows):
        """Write all rows (and the header) to the CSV file."""
        with open(self.FILE_PATH, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=self.FIELDS)
            writer.writeheader()
            writer.writerows(rows)

    def insert_employee(self, first_name, last_name, birthdate, hire_date, job_title):
        """Insert a new employee into the CSV file."""
        employees = self._read_csv()
        employee_id = len(employees) + 1  # Auto increment the ID
        employees.append({
            "id": employee_id,
            "first_name": first_name,
            "last_name": last_name,
            "birthdate": birthdate,
            "hire_date": hire_date,
            "job_title": job_title
        })
        self._write_csv(employees)

    def get_employee(self, first_name, last_name):
        """Retrieve a specific employee by name."""
        employees = self._read_csv()
        for emp in employees:
            if emp["first_name"] == first_name and emp["last_name"] == last_name:
                return \
                "ID: " + str(emp['id']) + ", " + \
                "Name: " + emp['first_name'] + " " + emp['last_name'] + ", " \
                "Birthdate: " + str(emp['birthdate']) + ", " + \
                "Hire Date: " + str(emp['hire_date']) + ", " + \
                "Job Title: " + str(emp['job_title'])
        return None  # Employee not found

    def get_all_employees(self):
        """Retrieve all employees."""
        return self._read_csv()
